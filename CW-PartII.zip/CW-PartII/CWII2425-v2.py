'''
Department of Computer Science, University of Bristol
COMS30030: Image Processing and Computer Vision

3-D from Stereo: Coursework Part 2
3-D simulator

Yuhang Ming yuhang.ming@bristol.ac.uk
Andrew Calway andrew@cs.bris.ac.uk
'''

import cv2
import open3d as o3d
import matplotlib.pyplot as plt
import numpy as np
import math
import random
import argparse

from scipy.spatial import distance


'''
Interaction menu:
P  : Take a screen capture.
D  : Take a depth capture.

Official doc on visualisation interactions:
http://www.open3d.org/docs/latest/tutorial/Basic/visualization.html
'''

def transform_points(points, H):
    '''
    transform list of 3-D points using 4x4 coordinate transformation matrix H
    converts points to homogeneous coordinates prior to matrix multiplication
    
    input:
      points: Nx3 matrix with each row being a 3-D point
      H: 4x4 transformation matrix
    
    return:
      new_points: Nx3 matrix with each row being a 3-D point
    '''
    # compute pt_w = H * pt_c
    n,m = points.shape
    if m == 4:
        new_points = points
    else:
        new_points = np.concatenate([points, np.ones((n,1))], axis=1)
    new_points = H.dot(new_points.transpose())
    new_points = new_points / new_points[3,:]
    new_points = new_points[:3,:].transpose()
    return new_points

def check_dup_locations(y, z, loc_list):
    for (loc_y, loc_z) in loc_list:
        if loc_y == y and loc_z == z:
            return True


# print("here", flush=True)
if __name__ == '__main__': 

    ####################################
    ### Take command line arguments ####
    ####################################

    parser = argparse.ArgumentParser()
    parser.add_argument('--num', dest='num', type=int, default=6, 
                        help='number of spheres')    
    parser.add_argument('--sph_rad_min', dest='sph_rad_min', type=int, default=10, 
                        help='min sphere  radius x10')
    parser.add_argument('--sph_rad_max', dest='sph_rad_max', type=int, default=16, 
                        help='max sphere  radius x10')
    parser.add_argument('--sph_sep_min', dest='sph_sep_min', type=int, default=4, 
                       help='min sphere  separation')
    parser.add_argument('--sph_sep_max', dest='sph_sep_max', type=int, default=8, 
                       help='max sphere  separation')
    parser.add_argument('--display_centre', dest='bCentre', action='store_true',
                        help='open up another visualiser to visualise centres')
    parser.add_argument('--coords', dest='bCoords', action='store_true')

    args = parser.parse_args()

    if args.num<=0:
        print('invalidnumber of spheres')
        exit()

    if args.sph_rad_min>=args.sph_rad_max or args.sph_rad_min<=0:
        print('invalid max and min sphere radii')
        exit()
    	
    if args.sph_sep_min>=args.sph_sep_max or args.sph_sep_min<=0:
        print('invalid max and min sphere separation')
        exit()
	
    ####################################
    #### Setup objects in the scene ####
    ####################################

    # create plane to hold all spheres
    h, w = 24, 12
    # place the support plane on the x-z plane
    box_mesh=o3d.geometry.TriangleMesh.create_box(width=h,height=0.05,depth=w)
    box_H=np.array(
                 [[1, 0, 0, -h/2],
                  [0, 1, 0, -0.05],
                  [0, 0, 1, -w/2],
                  [0, 0, 0, 1]]
                )
    box_rgb = [0.7, 0.7, 0.7]
    name_list = ['plane']
    mesh_list, H_list, RGB_list = [box_mesh], [box_H], [box_rgb]

    # create spheres
    prev_loc = []
    GT_cents, GT_rads = [], []
    for i in range(args.num):
        # add sphere name
        name_list.append(f'sphere_{i}')

        # create sphere with random radius
        size = random.randrange(args.sph_rad_min, args.sph_rad_max, 2)/10
        sph_mesh=o3d.geometry.TriangleMesh.create_sphere(radius=size)
        mesh_list.append(sph_mesh)
        RGB_list.append([0., 0.5, 0.5])

        # create random sphere location
        step = random.randrange(int(args.sph_sep_min),int(args.sph_sep_max),1)
        x = random.randrange(int(-h/2+2), int(h/2-2), step)
        z = random.randrange(int(-w/2+2), int(w/2-2), step)
        while check_dup_locations(x, z, prev_loc):
            x = random.randrange(int(-h/2+2), int(h/2-2), step)
            z = random.randrange(int(-w/2+2), int(w/2-2), step)
        prev_loc.append((x, z))

        GT_cents.append(np.array([x, size, z, 1.]))
        GT_rads.append(size)
        sph_H = np.array(
                    [[1, 0, 0, x],
                     [0, 1, 0, size],
                     [0, 0, 1, z],
                     [0, 0, 0, 1]]
                )
        H_list.append(sph_H)

    # arrange plane and sphere in the space
    obj_meshes = []
    for (mesh, H, rgb) in zip(mesh_list, H_list, RGB_list):
        # apply location
        mesh.vertices = o3d.utility.Vector3dVector(
            transform_points(np.asarray(mesh.vertices), H)
        )
        # paint meshes in uniform colours here
        mesh.paint_uniform_color(rgb)
        mesh.compute_vertex_normals()
        obj_meshes.append(mesh)

    # add optional coordinate system
    if args.bCoords:
        coord_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1., origin=[0, 0, 0])
        obj_meshes = obj_meshes+[coord_frame]
        RGB_list.append([1., 1., 1.])
        name_list.append('coords')


    ###################################
    #### Setup camera orientations ####
    ###################################

    # set camera pose (world to camera)
    # # camera init 
    # # placed at the world origin, and looking at z-positive direction, 
    # # x-positive to right, y-positive to down
    # H_init = np.eye(4)      
    # print(H_init)

    # camera_0 (world to camera)
    theta = np.pi * (45*5+random.uniform(-5, 5))/180.
    H0_wc = np.array(
                [[1,            0,              0,  0],
                [0, np.cos(theta), -np.sin(theta),  0], 
                [0, np.sin(theta),  np.cos(theta), 20], 
                [0, 0, 0, 1]]
            )

    # camera_1 (world to camera)
    theta = np.pi * (80+random.uniform(-10, 10))/180.
    H1_0 = np.array(
                [[np.cos(theta),  0, np.sin(theta), 0],
                 [0,              1, 0,             0],
                 [-np.sin(theta), 0, np.cos(theta), 0],
                 [0, 0, 0, 1]]
            )
    theta = np.pi * (45*5+random.uniform(-5, 5))/180.
    H1_1 = np.array(
                [[1, 0,            0,              0],
                [0, np.cos(theta), -np.sin(theta), -4],
                [0, np.sin(theta), np.cos(theta),  20],
                [0, 0, 0, 1]]
            )
    H1_wc = np.matmul(H1_1, H1_0)
    render_list = [(H0_wc, 'view0.png', 'depth0.png'), 
                   (H1_wc, 'view1.png', 'depth1.png')]

#####################################################
    # NOTE: This section relates to rendering scenes in Open3D, details are not
    # critical to understanding the lab, but feel free to read Open3D docs
    # to understand how it works.
    
    # set up camera intrinsic matrix needed for rendering in Open3D
    img_width=640
    img_height=480
    f=415 # focal length
    # image centre in pixel coordinates
    ox=img_width/2-0.5 
    oy=img_height/2-0.5
    K = o3d.camera.PinholeCameraIntrinsic(img_width,img_height,f,f,ox,oy)

    # Rendering RGB-D frames given camera poses
    # create visualiser and get rendered views
    cam = o3d.camera.PinholeCameraParameters()
    cam.intrinsic = K
    vis = o3d.visualization.Visualizer()
    vis.create_window(width=img_width, height=img_height, left=0, top=0)
    for m in obj_meshes:
        vis.add_geometry(m)
    ctr = vis.get_view_control()
    for (H_wc, name, dname) in render_list:
        cam.extrinsic = H_wc
        ctr.convert_from_pinhole_camera_parameters(cam,True)
        vis.poll_events()
        vis.update_renderer()
        vis.capture_screen_image(name, True)
        vis.capture_depth_image(dname, True)
    vis.run()
    vis.destroy_window()
##################################################

    # load in the images for post processings
    img0 = cv2.imread('view0.png', -1)
    dep0 = cv2.imread('depth0.png', -1)
    img1 = cv2.imread('view1.png', -1)
    dep1 = cv2.imread('depth1.png', -1)

    # visualise sphere centres
    pcd_GTcents = o3d.geometry.PointCloud()
    pcd_GTcents.points = o3d.utility.Vector3dVector(np.array(GT_cents)[:, :3])
    pcd_GTcents.paint_uniform_color([1., 0., 0.])
    if args.bCentre:
        vis = o3d.visualization.Visualizer()
        vis.create_window(width=640, height=480, left=0, top=0)
        for m in [obj_meshes[0], pcd_GTcents]:
            vis.add_geometry(m)
        vis.run()
        vis.destroy_window()

    
    ###################################
    '''
    Task 3: Circle detection
    Hint: use cv2.HoughCircles() for circle detection.
    https://docs.opencv.org/4.x/dd/d1a/group__imgproc__feature.html#ga47849c3be0d0406ad3ca45db65a25d2d

    Write your code here
    '''
    ###################################
    # Pre-process the image by turning it into grayscale and apply Gaussian blur
    img_0 = cv2.imread('view0.png', cv2.IMREAD_GRAYSCALE)
    blur_img_0 = cv2.GaussianBlur(img_0, (9, 9), 0)
    img_1 = cv2.imread('view1.png', cv2.IMREAD_GRAYSCALE)
    blur_img_1 = cv2.GaussianBlur(img_1, (9, 9), 0)

    # Apply Hough circle detection on the processed image
    circles_0 = cv2.HoughCircles(blur_img_0,cv2.HOUGH_GRADIENT,1.0,10,
                                param1=60,param2=40,minRadius=10,maxRadius=50)
    circles_1 = cv2.HoughCircles(blur_img_1,cv2.HOUGH_GRADIENT,1.0,10,
                                param1=60,param2=40,minRadius=10,maxRadius=50)
    
    # Draw the detected circle back on the image
    if circles_0 is not None:
        circles_0 = np.uint16(np.around(circles_0))
        for i in circles_0[0,:]:
            # draw the outer circle
            cv2.circle(img_0,(i[0],i[1]),i[2],(0,255,0),2)
            # draw the center of the circle
            cv2.circle(img_0,(i[0],i[1]),2,(0,0,255),3)
    
    if circles_1 is not None:
        circles_1 = np.uint16(np.around(circles_1))
        for i in circles_1[0,:]:
            # draw the outer circle
            cv2.circle(img_1,(i[0],i[1]),i[2],(0,255,0),2)
            # draw the center of the circle
            cv2.circle(img_1,(i[0],i[1]),2,(0,0,255),3)
    
    cv2.imshow('detected circles 0',img_0)
    cv2.imshow('detected circles 1',img_1)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


    ###################################
    '''
    Task 4: Epipolar line
    Hint: Compute Essential & Fundamental Matrix
          Draw lines with cv2.line() function
    https://docs.opencv.org/4.x/d6/d6e/group__imgproc__draw.html#ga7078a9fae8c7e7d13d24dac2520ae4a2
    
    Write your code here
    '''
    ###################################
    # Initializing SIFT detector to detect the matching point of both image
    sift = cv2.SIFT_create()
    kp1, des1 = sift.detectAndCompute(blur_img_0, None)
    kp2, des2 = sift.detectAndCompute(blur_img_1, None)

    bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck = False)
    matches = bf.match(des1, des2)
    good_matches = [m for m in matches if m.distance < 250] # Apply distance threshold on the matching point

    # Ensure enough goog matches to compute fundamental matrix
    if len(good_matches) < 8:
        print("Not enough good matches to compute fundamental marix")
        exit()

    # Extract corresponding points from the matches
    pts1 = np.float32([kp1[m.queryIdx].pt for m in good_matches])
    pts2 = np.float32([kp2[m.trainIdx].pt for m in good_matches])

    # Compute the fundamental matrix
    epipolar_line_array = []
    F, mask = cv2.findFundamentalMat(pts1, pts2, cv2.FM_RANSAC, ransacReprojThreshold=3.0)
    
    if F is not None:
        F = F[0:3, 0:3]
        print("Fundamental Matrix:\n", F)

        img_1 = cv2.imread('view1.png', cv2.IMREAD_GRAYSCALE)
        # For each detected circle, compute the epipolar line
        for i in circles_0[0,:]:
            circle_point = np.array([i[0], i[1], 1])
            epipolar_line = np.dot(F, circle_point)
            epipolar_line_array.append(epipolar_line)
            a,b,c = epipolar_line
            img_width=640
            img_height=480
            x1, y1 = 0, int(-c/b) 
            x2, y2 = img_width, int(-(a * img_width + c)/ b)
            # Draw the epipolar line in VC2
            cv2.line(img_1, (x1, y1), (x2, y2), (0, 0, 255), 2)

        cv2.imshow('VC1 with Circles', img_0)
        cv2.imshow('VC2 with Epipolar Lines', img_1)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
    
    else:
        print("Couldn't compute the fundamental matrix")
        exit()

    ###################################
    '''
    Task 5: Find correspondences

    Write your code here
    '''
    ###################################
    img_1 = cv2.imread('view1.png', cv2.IMREAD_GRAYSCALE)

    match_0 = []
    match_1 = []
    match_0_r = []
    match_1_r = []

    for k, line in enumerate(epipolar_line_array):
        matching_circle = None
        min_distance = float('inf')
        a,b,c = line

        for j in circles_1[0,:]:
            # compute the distance from circle centre detected with the epipolar line
            distances = abs(a * j[0] + b * j[1] + c) / np.sqrt(a**2 + b**2)
            if distances < 5:  
                if distances < min_distance:
                    min_distance = distances
                    matching_circle = (j[0], j[1], j[2])
            
            if matching_circle:
                # store the x and y coordinate of matching circle centre
                match_0.append(circles_0[0, k][:2])
                match_1.append(matching_circle[:2])

                # store the x and y coordinate  and the radius of matching circle centre
                match_0_r.append(circles_0[0, k])
                match_1_r.append(matching_circle)

                # draw the outer circle
                cv2.circle(img_1,(matching_circle[0],matching_circle[1]),matching_circle[2],(0,255,0),2)
                # draw the center of the circle
                cv2.circle(img_1,(matching_circle[0],matching_circle[1]),2,(0,0,255),3)

    match_0 = np.array(match_0, dtype=np.float32)
    match_1 = np.array(match_1, dtype=np.float32)
    match_0_r = np.array(match_0_r, dtype=np.float32)
    match_1_r = np.array(match_1_r, dtype=np.float32)

    cv2.imshow('VC1 with Circles', img_0)
    cv2.imshow('VC2 with Corresponding Cricles', img_1)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    ###################################
    '''
    Task 6: 3-D locations of sphere centres

    Write your code here
    '''
    ###################################
    # Intrinsic matrix for camera
    cameraMat = np.array([[415, 0, 320],  
                        [0, 415, 240],
                        [0, 0, 1]])
    # Rotation matrix as identity matrix and no translation for first view
    rotation_0 = np.eye(3)
    translation_0 = np.zeros((3, 1)) 

    # Extract the rotation and translation matrix from above for second view
    rotation_1 = H1_wc[:3, :3]
    translation_1 = H1_wc[:3, 3:]

    # projection matrix for both view 
    p0 = cameraMat @ np.hstack((rotation_0, translation_0))
    p1 = cameraMat @ np.hstack((rotation_1, translation_1))

    match_0_h = np.vstack((match_0.T, np.ones(match_0.shape[0])))
    match_1_h = np.vstack((match_1.T, np.ones(match_1.shape[0])))

    # compute the recontructed circle centre
    point4d = cv2.triangulatePoints(p0, p1, match_0_h[:2], match_1_h[:2])
    point3d = point4d[:3] / point4d[3]
    loc3d = point3d.T
    # remove duplicate points
    loc3d = np.unique(loc3d, axis = 0) 

    print("3D Coordinates of Sphere Centers:\n", loc3d)

    ###################################
    '''
    Task 7: Evaluate and Display the centres

    Write your code here
    '''
    ###################################
    # extract the ground truth of the centre
    groundTruth = np.array(GT_cents)[:, :3]

    # compute distance between all the ground truth with the reconstructed centre 
    pairDistance = distance.cdist(groundTruth, loc3d, metric = 'euclidean')
    indexes = np.argmin(pairDistance, axis = 1)
    minDist = np.min(pairDistance, axis = 1)
    threshold_gt = 10
    gt_index = minDist < threshold_gt

    # extracting matched ground truth and reconstructed centre
    valid_gt = groundTruth[gt_index]
    match_loc3d = loc3d[indexes[gt_index]]

    # compute the error between the reconstructed and ground truth centre 
    error = np.linalg.norm(match_loc3d - valid_gt, axis = 1)
    print("Reconstruction error for each centre:\n", error)

    error_mean = np.mean(error)
    print(" Mean reconstruction error:", error_mean)

    # visualize the pointcloud of the centres 
    groundTruth_point = o3d.geometry.PointCloud()
    groundTruth_point.points = o3d.utility.Vector3dVector(groundTruth)
    groundTruth_point.paint_uniform_color([1.0, 0.0, 0.0])

    recontructed_point = o3d.geometry.PointCloud()
    recontructed_point.points = o3d.utility.Vector3dVector(match_loc3d)
    recontructed_point.paint_uniform_color([0.0, 1.0, 0.0])

    o3d.visualization.draw_geometries([groundTruth_point, recontructed_point], window_name="Ground truth and Reconstructed")

    ###################################
    '''
    Task 8: 3-D radius of spheres

    Write your code here
    '''
    ###################################
    match_0_r = np.array(match_0_r)
    match_1_r = np.array(match_1_r)
    # extract only the radius of matched circle centre
    radius_0 = match_0_r[:, 2]  
    radius_1 = match_1_r[:, 2] 
    radius_avg = (radius_0 + radius_1[:len(radius_0)]) / 2 
    z3d = np.abs(match_loc3d[:, 2])

    minSize = min(len(radius_avg), len(z3d))
    if minSize < 6:
        radius_avg = radius_avg[:minSize]
        z3d = z3d[:minSize]
    else:
        radius_avg = radius_avg[:6]
        z3d = z3d[:6]

    # compute the 3d radius of each circle
    radius_3d = radius_avg * z3d[:len(radius_avg)]
    
    print("Average 2d radius:", radius_avg)
    print("Depths:", z3d[:len(radius_avg)])
    print("Estimated 3d radius:", radius_3d)
    ###################################
    '''
    Task 9: Display the spheres

    Write your code here:
    '''
    ###################################
    # extract matched ground truth radius 
    groundTruth_radius = np.array(GT_rads)
    valid_gt_radius = groundTruth_radius[gt_index]

    # compute the radius error between the rconstructed and ground truth
    error_radius = np.abs(radius_3d - valid_gt_radius[:len(radius_3d)])
    error_radius_mean = np.mean(error_radius)

    print("Radius error for each sphere:", error_radius)
    print("Mean radius error:", error_radius_mean)

    # visualize all the sphere
    obj = []
    for i, cent in enumerate(groundTruth):
        sphere = o3d.geometry.TriangleMesh.create_sphere(radius=groundTruth_radius[i])
        sphere.translate(cent)
        sphere.paint_uniform_color([1, 0, 0])
        obj.append(sphere)

    minSizes = min(len(radius_3d), len(loc3d))
    if minSizes < 6:
        radius_3d = radius_3d[:minSizes]
        loc3d = loc3d[:minSizes]
    else: 
        radius_3d = radius_3d[:6]
        loc3d = loc3d[:6]
    
    for j, est_cent in enumerate(loc3d):
        sphere = o3d.geometry.TriangleMesh.create_sphere(radius=radius_3d[j])
        sphere.translate(cent)
        sphere.paint_uniform_color([0, 1, 0])
        obj.append(sphere)

    o3d.visualization.draw_geometries(obj, window_name="Ground truth and reconstructed sphere")

    ###################################
    '''
    Task 10: Investigate impact of noise added to relative pose

    Write your code here:
    '''
    ###################################
